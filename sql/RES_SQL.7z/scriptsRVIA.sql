-- DROP TABLE cat_centros CASCADE;
CREATE TABLE IF NOT EXISTS cat_centros
(
    num_centro int NOT NULL,
    nom_centro varchar(50) NOT NULL,
    fec_movto timestamp without time zone NOT NULL DEFAULT now(),
    keyx serial NOT NULL,
	UNIQUE(num_centro),
	CONSTRAINT pk_cat_centros PRIMARY KEY (keyx, num_centro)
)
WITHOUT OIDS;

GRANT select, insert, update, delete ON TABLE cat_centros TO sysdesarrollorvia;

COMMENT ON TABLE cat_centros IS 'Datos de los Centros';
COMMENT ON COLUMN cat_centros.num_centro IS 'Número del Centro (Primary Key)';
COMMENT ON COLUMN cat_centros.nom_centro IS 'Nombre del Centro';
COMMENT ON COLUMN cat_centros.fec_movto IS 'fecha de inserción del movimiento';
COMMENT ON COLUMN cat_centros.keyx IS 'Indicador automático consecutivo de la tabla (autoincremental)';

 --index
CREATE INDEX idx_cat_centros_numerocentro ON cat_centros (num_centro);
CREATE INDEX idx_cat_centros_nombrecentro ON cat_centros (nom_centro);
CREATE INDEX idx_cat_centros_keyx ON cat_centros (keyx);

INSERT INTO cat_centros (num_centro, nom_centro) VALUES ('0'::int, ''::varchar);
INSERT INTO cat_centros (num_centro, nom_centro) VALUES ('230190'::int, 'CLCN SIST PROG IV SERV FINANCIEROS'::varchar);
INSERT INTO cat_centros (num_centro, nom_centro) VALUES ('230578'::int, 'CLCN DESARROLLO SIST A+B VI'::varchar);
INSERT INTO cat_centros (num_centro, nom_centro) VALUES ('231637'::int, 'CLCN REMED DE VUL RETAIL'::varchar);
INSERT INTO cat_centros (num_centro, nom_centro) VALUES ('231639'::int, 'CLCN RV DESARROLLO RETAIL I'::varchar);
INSERT INTO cat_centros (num_centro, nom_centro) VALUES ('231640'::int, 'CLCN RV DESARROLLO RETAIL II'::varchar);
INSERT INTO cat_centros (num_centro, nom_centro) VALUES ('231641'::int, 'CLCN RV DESARROLLO RETAIL III'::varchar);
INSERT INTO cat_centros (num_centro, nom_centro) VALUES ('231642'::int, 'CLCN RV DESARROLLO RETAIL IV'::varchar);
INSERT INTO cat_centros (num_centro, nom_centro) VALUES ('231643'::int, 'CLCN RV DESARROLLO OM Y SF I'::varchar);
INSERT INTO cat_centros (num_centro, nom_centro) VALUES ('231644'::int, 'CLCN RV DESARROLLO OM Y SF II'::varchar);
INSERT INTO cat_centros (num_centro, nom_centro) VALUES ('231645'::int, 'CLCN RV DESARROLLO OM Y SF III'::varchar);
INSERT INTO cat_centros (num_centro, nom_centro) VALUES ('231646'::int, 'CLCN RV DESARROLLO OM Y SF IV'::varchar);
INSERT INTO cat_centros (num_centro, nom_centro) VALUES ('231649'::int, 'CLCN RV PROY INFRAESTRUCTURA'::varchar);
INSERT INTO cat_centros (num_centro, nom_centro) VALUES ('232390'::int, 'CLCN REMED DE VUL OMNIC Y SF'::varchar);
INSERT INTO cat_centros (num_centro, nom_centro) VALUES ('232490'::int, 'CLCN ANALISIS DE REQ AFORE'::varchar);

//-- Puestos
-- SELECT * FROM cat_puestos;
-- DROP TABLE cat_puestos CASCADE;
CREATE TABLE IF NOT EXISTS cat_puestos
(
    num_puesto smallint NOT NULL,
    nom_puesto varchar(50) NOT NULL,
	fec_movto timestamp without time zone NOT NULL DEFAULT now(),
    keyx serial NOT NULL,
	UNIQUE(num_puesto),
	CONSTRAINT pk_cat_puestos PRIMARY KEY (keyx, num_puesto)
)
WITHOUT OIDS;

GRANT select, insert, update, delete ON TABLE cat_puestos TO sysdesarrollorvia;

COMMENT ON TABLE cat_puestos IS 'Datos de los puestos';
COMMENT ON COLUMN cat_puestos.num_puesto IS 'Número del puesto (Primary Key)';
COMMENT ON COLUMN cat_puestos.nom_puesto IS 'Nombre del puesto';
COMMENT ON COLUMN cat_puestos.fec_movto IS 'fecha de inserción del movimiento';
COMMENT ON COLUMN cat_puestos.keyx IS 'Indicador automático consecutivo de la tabla (autoincremental)';

 --index

CREATE INDEX idx_cat_puestos_num_puesto ON cat_puestos (num_puesto);
CREATE INDEX idx_cat_puestos_nom_puesto ON cat_puestos (nom_puesto);
CREATE INDEX idx_cat_puestos_keyx ON cat_puestos (keyx);

INSERT INTO cat_puestos (num_puesto, nom_puesto) VALUES ('0'::smallint, ''::varchar);
INSERT INTO cat_puestos (num_puesto, nom_puesto) VALUES ('37'::smallint, 'ENTRENAMIENTO'::varchar);
INSERT INTO cat_puestos (num_puesto, nom_puesto) VALUES ('42'::smallint, 'JEFE'::varchar);
INSERT INTO cat_puestos (num_puesto, nom_puesto) VALUES ('077'::smallint, 'PROGRAMADOR'::varchar);
INSERT INTO cat_puestos (num_puesto, nom_puesto) VALUES ('364'::smallint, 'GERENTE DE DESARROLLO'::varchar);
INSERT INTO cat_puestos (num_puesto, nom_puesto) VALUES ('442'::smallint, 'TESTER'::varchar);
INSERT INTO cat_puestos (num_puesto, nom_puesto) VALUES ('444'::smallint, 'ARQUITECTO DE SOFTWARE'::varchar);
INSERT INTO cat_puestos (num_puesto, nom_puesto) VALUES ('136'::smallint, 'LÍDER DE PROYECTO'::varchar);
INSERT INTO cat_puestos (num_puesto, nom_puesto) VALUES (''::smallint, 'ANALISTA DE SISTEMAS'::varchar);



//----------- cat_proveedores
-- DROP TABLE cat_proveedores CASCADE;
CREATE TABLE IF NOT EXISTS cat_proveedores
(
	num_proveedor smallint NOT NULL,
    nom_proveedor varchar(50) NOT NULL,
	fec_movto timestamp without time zone NOT NULL DEFAULT now(),
    keyx serial NOT NULL,
	UNIQUE(num_proveedor),
    CONSTRAINT pk_cat_proveedores PRIMARY KEY (keyx, num_proveedor)
)
WITHOUT OIDS;

GRANT select, insert, update, delete ON TABLE cat_proveedores TO sysdesarrollorvia;

COMMENT ON TABLE cat_proveedores IS 'Datos de los proveedores';
COMMENT ON COLUMN cat_proveedores.num_proveedor IS 'Número del Proveedor';
COMMENT ON COLUMN cat_proveedores.nom_proveedor IS 'Nombre del Proveedor';
COMMENT ON COLUMN cat_proveedores.fec_movto IS 'fecha de inserción del movimiento';
COMMENT ON COLUMN cat_proveedores.keyx IS 'Indicador automático consecutivo de la tabla (autoincremental)  (Primary key)';

 --index
CREATE INDEX idx_cat_proveedores_num_proveedor ON cat_proveedores (num_proveedor);
CREATE INDEX idx_cat_proveedores_nom_proveedor ON cat_proveedores (nom_proveedor);
CREATE INDEX idx_cat_proveedores_keyx ON cat_proveedores (keyx);

INSERT INTO cat_proveedores (num_proveedor, nom_proveedor) VALUES ('0'::smallint, ''::varchar);
INSERT INTO cat_proveedores (num_proveedor, nom_proveedor) VALUES ('1'::smallint, 'Softtek'::varchar);
INSERT INTO cat_proveedores (num_proveedor, nom_proveedor) VALUES ('2'::smallint, 'Neoris'::varchar);
INSERT INTO cat_proveedores (num_proveedor, nom_proveedor) VALUES ('3'::smallint, 'AP Interfaces'::varchar);
INSERT INTO cat_proveedores (num_proveedor, nom_proveedor) VALUES ('4'::smallint, 'Coppel'::varchar);



//------------------------ Divisionales
-- SELECT * FROM cat_divisionales;
-- DROP TABLE cat_divisionales CASCADE;
CREATE TABLE IF NOT EXISTS cat_divisionales
(
    num_divisional bigint NOT NULL,
    nom_divisional varchar(60) NOT NULL,
    fec_movto timestamp without time zone NOT NULL DEFAULT now(),
    keyx serial NOT NULL,
	UNIQUE(num_divisional),
    CONSTRAINT pk_cat_divisionales PRIMARY KEY (keyx, num_divisional)
)
WITHOUT OIDS;

GRANT select, insert, update, delete ON TABLE cat_divisionales TO sysdesarrollorvia;

COMMENT ON TABLE cat_divisionales IS 'Datos de los divisionales involucrados en los proyectos';
COMMENT ON COLUMN cat_divisionales.num_divisional IS 'Número de empleado del Divisional  (Primary key)';
COMMENT ON COLUMN cat_divisionales.nom_divisional IS 'Nombre del Divisional';
COMMENT ON COLUMN cat_divisionales.fec_movto IS 'fecha de inserción del movimiento';
COMMENT ON COLUMN cat_divisionales.keyx IS 'Indicador automático consecutivo de la tabla (autoincremental)';

 --index
CREATE INDEX idx_cat_divisionales_num_divisional ON cat_divisionales (num_divisional);
CREATE INDEX idx_cat_divisionales_nom_divisional ON cat_divisionales (nom_divisional);
CREATE INDEX idx_cat_divisionales_keyx ON cat_divisionales (keyx);

INSERT INTO cat_divisionales (num_divisional, nom_divisional) VALUES('90017854'::bigint, 'José Guadalupe Mendoza Macías'::varchar);

//------------------------ Nacionales
-- SELECT * FROM cat_nacionales;
-- DROP TABLE cat_nacionales CASCADE;
CREATE TABLE IF NOT EXISTS cat_nacionales
(
    num_nacional bigint NOT NULL,
    nom_nacional varchar(60) NOT NULL,
    fec_movto timestamp without time zone NOT NULL DEFAULT now(),
    keyx serial NOT NULL,
	UNIQUE(num_nacional),
    CONSTRAINT pk_cat_nacionales PRIMARY KEY (keyx, num_nacional)
)
WITHOUT OIDS;

GRANT select, insert, update, delete ON TABLE cat_nacionales TO sysdesarrollorvia;

COMMENT ON TABLE cat_nacionales IS 'Datos de los Nacionales involucrados en los proyectos';
COMMENT ON COLUMN cat_nacionales.num_nacional IS 'Número de empleado del Nacional  (Primary key)';
COMMENT ON COLUMN cat_nacionales.nom_nacional IS 'Nombre del Nacional';
COMMENT ON COLUMN cat_nacionales.fec_movto IS 'fecha de inserción del movimiento';
COMMENT ON COLUMN cat_nacionales.keyx IS 'Indicador automático consecutivo de la tabla (autoincremental)';

 --index
CREATE INDEX idx_cat_nacionales_num_nacional ON cat_nacionales (num_nacional);
CREATE INDEX idx_cat_nacionales_nom_nacional ON cat_nacionales (nom_nacional);
CREATE INDEX idx_cat_nacionales_keyx ON cat_nacionales (keyx);

INSERT INTO cat_nacionales(num_nacional, nom_nacional) VALUES('96652551'::integer, 'Teresa Guadalupe Gálvez Gastelum'::varchar);
INSERT INTO cat_nacionales(num_nacional, nom_nacional) VALUES('90203224'::integer, 'Héctor Antonio Cruz Zazueta'::varchar);


//--------------- cat_coordinadores
-- SELECT * FROM cat_coordinadores;
-- DROP TABLE cat_coordinadores CASCADE;
CREATE TABLE IF NOT EXISTS cat_coordinadores
(
    num_coordinador bigint NOT NULL,
    nom_coordinador varchar(60) NOT NULL,
	fec_movto timestamp without time zone NOT NULL DEFAULT now(),
    keyx serial NOT NULL,
	UNIQUE(num_coordinador),
    CONSTRAINT pk_cat_coordinadores PRIMARY KEY (keyx, num_coordinador)
)
WITHOUT OIDS;

GRANT select, insert, update, delete ON TABLE cat_coordinadores TO sysdesarrollorvia;

COMMENT ON TABLE cat_coordinadores IS 'Datos de los Coordinadores involucrados en los proyectos';
COMMENT ON COLUMN cat_coordinadores.num_coordinador IS 'Número de empleado del Coordinador  (Primary key)';
COMMENT ON COLUMN cat_coordinadores.nom_coordinador IS 'Nombre del Coordinador';
COMMENT ON COLUMN cat_coordinadores.fec_movto IS 'fecha de inserción del movimiento';
COMMENT ON COLUMN cat_coordinadores.keyx IS 'Indicador automático consecutivo de la tabla (autoincremental)';

 --index
CREATE INDEX idx_cat_coordinadores_num_coordinador ON cat_coordinadores (num_coordinador);
CREATE INDEX idx_cat_coordinadores_nom_coordinador ON cat_coordinadores (nom_coordinador);
CREATE INDEX idx_cat_coordinadores_keyx ON cat_coordinadores (keyx);

INSERT INTO cat_coordinadores(num_coordinador, nom_coordinador) VALUES('0'::integer, ''::varchar);
INSERT INTO cat_coordinadores(num_coordinador, nom_coordinador) VALUES('91080819'::integer, 'Gilberto Valenzuela Alvarez'::varchar);
INSERT INTO cat_coordinadores(num_coordinador, nom_coordinador) VALUES('91452716'::integer, 'Georgina Maria Del Rosario Gerardo Diaz'::varchar);
INSERT INTO cat_coordinadores(num_coordinador, nom_coordinador) VALUES('90035135'::integer, 'Oscar Alberto Aguilar Aramburo'::varchar);
INSERT INTO cat_coordinadores(num_coordinador, nom_coordinador) VALUES('90035313'::integer, 'Luis Enrique Rodríguez López'::varchar);

//----------------- cat_gerentes
-- SELECT * FROM cat_gerentes;
-- DROP TABLE cat_gerentes CASCADE;
CREATE TABLE IF NOT EXISTS cat_gerentes
(
    num_gerente bigint NOT NULL,
    nom_gerente varchar(60) NOT NULL,
	fec_movto timestamp without time zone NOT NULL DEFAULT now(),
    keyx serial NOT NULL,
	UNIQUE(num_gerente),
    CONSTRAINT pk_cat_gerentes PRIMARY KEY (keyx, num_gerente)
)
WITHOUT OIDS;

GRANT select, insert, update, delete ON TABLE cat_gerentes TO sysdesarrollorvia;

COMMENT ON TABLE cat_gerentes IS '';
COMMENT ON COLUMN cat_gerentes.num_gerente IS 'Número de empleado del Gerente  (Primary key)';
COMMENT ON COLUMN cat_gerentes.nom_gerente IS 'Nombre del Gerente';
COMMENT ON COLUMN cat_gerentes.fec_movto IS 'fecha de inserción del movimiento';
COMMENT ON COLUMN cat_gerentes.keyx IS 'Indicador automático consecutivo de la tabla (autoincremental)';

 --index
CREATE INDEX idx_cat_gerentes_num_gerente ON cat_gerentes (num_gerente);
CREATE INDEX idx_cat_gerentes_nom_gerente ON cat_gerentes (nom_gerente);
CREATE INDEX idx_cat_gerentes_keyx ON cat_gerentes (keyx);

INSERT INTO cat_gerentes(num_gerente, nom_gerente) VALUES('0'::integer, ''::varchar);
INSERT INTO cat_gerentes(num_gerente, nom_gerente) VALUES('90329121'::integer, 'José Arturo Solís Ramírez'::varchar);
INSERT INTO cat_gerentes(num_gerente, nom_gerente) VALUES('96665701'::integer, 'Cristabel Silva Barraza'::varchar);
INSERT INTO cat_gerentes(num_gerente, nom_gerente) VALUES('92474934'::integer, 'Marcos Antonio Cuevas Rodríguez'::varchar);
INSERT INTO cat_gerentes(num_gerente, nom_gerente) VALUES('95657861'::integer, 'Yareli Lizeth Calderon Coronel'::varchar);
INSERT INTO cat_gerentes(num_gerente, nom_gerente) VALUES('92102115'::integer, 'Claudia Batiz Beltrán'::varchar);
INSERT INTO cat_gerentes(num_gerente, nom_gerente) VALUES('92853341'::integer, 'Roberto Carlos Santillán Torres'::varchar);
INSERT INTO cat_gerentes(num_gerente, nom_gerente) VALUES('94812519'::integer, 'Teofilo Inzunza Payán'::varchar);
INSERT INTO cat_gerentes(num_gerente, nom_gerente) VALUES('94353638'::integer, 'Ruben Octavio Manjarrez Hernández'::varchar);
INSERT INTO cat_gerentes(num_gerente, nom_gerente) VALUES('91712467'::integer, 'José Rodolfo Uriarte Ramírez'::varchar);
INSERT INTO cat_gerentes(num_gerente, nom_gerente) VALUES('95555897'::integer, 'Sofia Carrazco Valenzuela'::varchar);


------------------------------------
------------------------------
-- SELECT * FROM cat_roles;
-- DROP TABLE cat_roles CASCADE;
CREATE TABLE cat_roles
(
	num_rol smallint NOT NULL,
    nom_rol varchar(30) NOT NULL,
	fec_movto timestamp without time zone NOT NULL DEFAULT now(),
	keyx serial NOT NULL,
	UNIQUE(num_rol),
    CONSTRAINT pk_cat_roles PRIMARY KEY (keyx, num_rol, nom_rol)
)
WITHOUT OIDS;

GRANT select, insert, update, delete ON TABLE cat_roles TO sysdesarrollorvia;

COMMENT ON TABLE cat_roles IS 'Datos de los roles involucrados en los proyectos';
COMMENT ON COLUMN cat_roles.num_rol IS 'Número del rol';
COMMENT ON COLUMN cat_roles.nom_rol IS 'Nombre de rol';
COMMENT ON COLUMN cat_roles.fec_movto IS 'Fecha de inserción del registro';
COMMENT ON COLUMN cat_roles.keyx IS 'Indicador automático consecutivo de la tabla (autoincremental) (Primary key)';

 --index

CREATE INDEX idx_cat_roles_keyx ON cat_roles (keyx);
CREATE INDEX idx_cat_roles_numrol ON cat_roles (num_rol);
CREATE INDEX idx_cat_roles_nombrerol ON cat_roles (nom_rol);

INSERT INTO cat_roles(num_rol, nom_rol) VALUES( '77'::smallint, 'Programador'::varchar);
INSERT INTO cat_roles(num_rol, nom_rol) VALUES( '136'::smallint, 'Líder de proyectos'::varchar);
INSERT INTO cat_roles(num_rol, nom_rol) VALUES( '444'::smallint, 'Arquitecto de software'::varchar);
INSERT INTO cat_roles(num_rol, nom_rol) VALUES( '000'::smallint, 'Analista de requerimientos'::varchar);
INSERT INTO cat_roles(num_rol, nom_rol) VALUES( '442'::smallint, 'Tester'::varchar);

------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------
--------------- cat_colaboradores
-- SELECT * FROM cat_colaboradores;
-- DROP TABLE cat_colaboradores CASCADE;

CREATE TABLE IF NOT EXISTS cat_colaboradores
(
    num_colaborador bigint NOT NULL,
    nom_colaborador varchar(60) NOT NULL,
	num_puesto smallint NOT NULL,  		-- Hereda de la tabla cat_puestos    
	num_centro int NOT NULL,	
	num_proveedor smallint NOT NULL, 	-- Hereda de la tabla cat_proveedores	
    num_gerente bigint NOT NULL,
	num_coordinador bigint NOT NULL,	
	fec_movto timestamp without time zone NOT NULL DEFAULT now(),
    keyx serial NOT NULL,
	UNIQUE(num_colaborador),
    CONSTRAINT pk_cat_colaboradores PRIMARY KEY (keyx, num_colaborador),
	CONSTRAINT fk_cat_colaboradores_cat_puestos FOREIGN KEY (num_puesto) REFERENCES cat_puestos (num_puesto),
	CONSTRAINT fk_cat_colaboradores_cat_centros FOREIGN KEY (num_centro) REFERENCES cat_centros (num_centro),
	CONSTRAINT fk_cat_colaboradores_cat_proveedores FOREIGN KEY (num_proveedor) REFERENCES cat_proveedores (num_proveedor),
	CONSTRAINT fk_cat_colaboradores_cat_gerentes FOREIGN KEY (num_gerente) REFERENCES cat_gerentes (num_gerente),
	CONSTRAINT fk_cat_colaboradores_cat_coordinadores FOREIGN KEY (num_coordinador) REFERENCES cat_coordinadores (num_coordinador)
)
WITHOUT OIDS;

-- ALTER TABLE cat_colaboradores ADD CONSTRAINT fk_cat_colaboradores_cat_centros FOREIGN KEY (num_centro) REFERENCES cat_centros (num_centro);

GRANT select, insert, update, delete ON TABLE cat_colaboradores TO sysdesarrollorvia;

COMMENT ON TABLE cat_colaboradores IS 'Datos de los colaboradores involucrados en los proyectos';
COMMENT ON COLUMN cat_colaboradores.num_colaborador IS 'Número de empleado del colaborador  (Primary key)';
COMMENT ON COLUMN cat_colaboradores.nom_colaborador IS 'Nombre del colaborador';
COMMENT ON COLUMN cat_colaboradores.num_puesto IS 'Número de puesto al que pertenece el colaborador';
COMMENT ON COLUMN cat_colaboradores.num_centro IS 'Número de centro al que pertenece el colaborador';
COMMENT ON COLUMN cat_colaboradores.num_proveedor IS 'Número del proveedor al que pertenece el colaborador';
COMMENT ON COLUMN cat_colaboradores.num_gerente IS 'Número de gerente al que pertenece el colaborador';
COMMENT ON COLUMN cat_colaboradores.num_coordinador IS 'Número de coordinador al que pertenece el colaborador';
COMMENT ON COLUMN cat_colaboradores.fec_movto IS 'fecha de inserción del movimiento';
COMMENT ON COLUMN cat_colaboradores.keyx IS 'Indicador automático consecutivo de la tabla (autoincremental)';

 --index
CREATE INDEX idx_cat_colaboradores_num_colaborador ON cat_colaboradores (num_colaborador);
CREATE INDEX idx_cat_colaboradores_nom_colaborador ON cat_colaboradores (nom_colaborador);
CREATE INDEX idx_cat_colaboradores_keyx ON cat_colaboradores (keyx);

-- INSERT INTO cat_colaboradores (num_colaborador, nom_colaborador, num_puesto, num_centro, num_proveedor, num_gerente, num_coordinador ) VALUES('97290645'::integer, 'Carmen Maria Carrillo Gonzalez'::varchar, '136'::smallint, '231644'::integer, '4'::smallint, '90329121'::integer, '91080819'::integer );

-- INSERT INTO cat_colaboradores (num_colaborador, nom_colaborador, num_puesto, num_centro, num_proveedor, num_gerente, num_coordinador ) VALUES('97290645'::integer, 'Carmen Maria Carrillo Gonzalez'::varchar, '136'::smallint, '231644'::integer, '4'::smallint, '90329121'::integer, '91080819'::integer );
-- INSERT INTO cat_colaboradores (num_colaborador, nom_colaborador, num_puesto, num_centro, num_proveedor, num_gerente, num_coordinador ) VALUES('96665701'::integer, 'Cristabel Silva Barraza'::varchar, '136'::smallint, '231643'::integer, '4'::smallint, '96665701'::integer, '91080819'::integer );
-- INSERT INTO cat_colaboradores (num_colaborador, nom_colaborador, num_puesto, num_centro, num_proveedor, num_gerente, num_coordinador ) VALUES('92474934'::integer, 'Marcos Antonio Cuevas Rodríguez'::varchar, '136'::smallint, '231646'::integer, '4'::smallint, '92474934'::integer, '91452716'::integer );
-- INSERT INTO cat_colaboradores (num_colaborador, nom_colaborador, num_puesto, num_centro, num_proveedor, num_gerente, num_coordinador ) VALUES('95657861'::integer, 'Yareli Lizeth Calderon Coronel'::varchar, '136'::smallint, '231645'::integer, '4'::smallint, '95657861'::integer, '91452716'::integer );
-- INSERT INTO cat_colaboradores (num_colaborador, nom_colaborador, num_puesto, num_centro, num_proveedor, num_gerente, num_coordinador ) VALUES('92102115'::integer, 'Claudia Batiz Beltrán'::varchar, '136'::smallint, '231649'::integer, '4'::smallint, '92102115'::integer, '91452716'::integer );
-- INSERT INTO cat_colaboradores (num_colaborador, nom_colaborador, num_puesto, num_centro, num_proveedor, num_gerente, num_coordinador ) VALUES('92853341'::integer, 'Roberto Carlos Santillán Torres'::varchar, '136'::smallint, '231639'::integer, '4'::smallint, '92853341'::integer, '90035135'::integer );
-- INSERT INTO cat_colaboradores (num_colaborador, nom_colaborador, num_puesto, num_centro, num_proveedor, num_gerente, num_coordinador ) VALUES('94812519'::integer, 'Teofilo Inzunza Payán'::varchar, '136'::smallint, '231640'::integer, '4'::smallint, '94812519'::integer, '90035135'::integer );
-- INSERT INTO cat_colaboradores (num_colaborador, nom_colaborador, num_puesto, num_centro, num_proveedor, num_gerente, num_coordinador ) VALUES('94353638'::integer, 'Ruben Octavio Manjarrez Hernández'::varchar, '136'::smallint, '231641'::integer, '4'::smallint, '94353638'::integer, '90035313'::integer );
-- INSERT INTO cat_colaboradores (num_colaborador, nom_colaborador, num_puesto, num_centro, num_proveedor, num_gerente, num_coordinador ) VALUES('91712467'::integer, 'José Rodolfo Uriarte Ramírez'::varchar, '136'::smallint, '231642'::integer, '4'::smallint, '91712467'::integer, '90035313'::integer );


------ ctl_proyectos
-- SELECT * FROM ctl_proyectos;
-- DROP TABLE ctl_proyectos CASCADE;

CREATE TABLE IF NOT EXISTS ctl_proyectos
(
    num_gerente bigint NOT NULL,				-- Se alimenta por la captura
    nom_gerente varchar(60) NOT NULL, 			-- Sale de la tabla cat_gerentes    
    nom_proyecto varchar(100) NOT NULL,			-- Se alimenta por la captura
	des_proyecto character varying(8000) NOT NULL, -- Se alimenta por la captura
	num_colaborador bigint NOT NULL,			-- Se alimenta por la captura
    nom_colaborador varchar(60) NOT NULL,		-- Sale de la tabla cat_colaboradores
    num_puesto smallint NOT NULL,		        -- Sale de la tabla cat_colaboradores
    nom_puesto varchar(30) NOT NULL,			-- Sale de la tabla cat_puestos
	num_rol smallint NOT NULL,					-- Se alimenta por la captura
    nom_rol varchar(30) NOT NULL,				-- Se alimenta por la captura
    num_centro int NOT NULL,					-- Sale de la tabla cat_colaboradores
    nom_centro varchar(50) NOT NULL,			-- Sale de la tabla cat_centros
    num_proveedor smallint NOT NULL,			-- Sale de la tabla cat_colaboradores
    nom_proveedor varchar(50) NOT NULL,			-- Sale de la tabla cat_proveedores
    num_coordinador bigint NOT NULL,			-- Sale de la tabla cat_colaboradores
    nom_coordinador varchar(60) NOT NULL,		-- Sale de la tabla cat_coordinadores
    num_nacional bigint NOT NULL,				-- Sale de la tabla cat_nacionales según el número del coordinador
    nom_nacional varchar(60) NOT NULL,			-- Sale de la tabla cat_nacionales según el número del coordinador
    fec_inicio date NOT NULL,					-- Se alimenta por la captura
	fec_promesa date NOT NULL,							-- Se alimenta por la captura
	fec_realfin date, 							-- Se alimenta por la captura
    num_ip varchar(16) NOT NULL,				-- Se alimenta por la captura
    num_macaddress char(13) NOT NULL,			-- Se alimenta por la captura
    num_latitud numeric(10,8) NOT NULL,			-- Se alimenta por la captura
    num_longitud numeric(10,8) NOT NULL,		-- Se alimenta por la captura
    fec_movto timestamp without time zone NOT NULL DEFAULT now(),
    flg_activo integer NOT NULL DEFAULT 0,
	keyx_proyectos_rv bigint NOT NULL,			-- Sale de la tabla ctl_proyectos_rv según nombre del sistema.
	keyx serial NOT NULL,
	UNIQUE(keyx),
    CONSTRAINT pk_ctl_proyectos PRIMARY KEY (keyx),
	CONSTRAINT fk_ctl_proyectos_cat_colaboradores FOREIGN KEY (num_colaborador) REFERENCES cat_colaboradores (num_colaborador),
	CONSTRAINT fk_ctl_proyectos_cat_puestos FOREIGN KEY (num_puesto) REFERENCES cat_puestos (num_puesto),
	CONSTRAINT fk_ctl_proyectos_cat_roles FOREIGN KEY (num_rol) REFERENCES cat_roles (num_rol),
	CONSTRAINT fk_ctl_proyectos_cat_centros FOREIGN KEY (num_centro) REFERENCES cat_centros (num_centro),
	CONSTRAINT fk_ctl_proyectos_cat_gerentes FOREIGN KEY (num_gerente) REFERENCES cat_gerentes (num_gerente),
	CONSTRAINT fk_ctl_proyectos_cat_proveedores FOREIGN KEY (num_proveedor) REFERENCES cat_proveedores (num_proveedor),
	CONSTRAINT fk_ctl_proyectos_cat_coordinadores FOREIGN KEY (num_coordinador) REFERENCES cat_coordinadores (num_coordinador),
	CONSTRAINT fk_ctl_proyectos_cat_nacionales FOREIGN KEY (num_nacional) REFERENCES cat_nacionales (num_nacional)
)
WITHOUT OIDS;


GRANT select, insert, update, delete ON TABLE ctl_proyectos TO sysdesarrollorvia;

COMMENT ON TABLE ctl_proyectos IS 'Datos de empleados que llevaran el desarrollo de un proyecto';
COMMENT ON COLUMN ctl_proyectos.num_colaborador IS 'Número de empleado del Colaborador (constraint)';
COMMENT ON COLUMN ctl_proyectos.nom_colaborador IS 'Nombre del Colaborador';
COMMENT ON COLUMN ctl_proyectos.flg_activo IS 'Identificador de empleado activo o inactivo dentro del proyecto, false = inactivo, true = activo';
COMMENT ON COLUMN ctl_proyectos.num_puesto IS 'Número de puesto del Colaborador (constraint)';
COMMENT ON COLUMN ctl_proyectos.nom_puesto IS 'Nombre de puesto del Colaborador';
COMMENT ON COLUMN ctl_proyectos.num_rol IS 'Número del rol que desempeña el colaborador en el proyecto';
COMMENT ON COLUMN ctl_proyectos.nom_rol IS 'Nombre del rol que desempeña el colaborador en el proyecto';
COMMENT ON COLUMN ctl_proyectos.nom_proyecto IS 'Nombre de proyecto al que pertenece el Colaborador';
COMMENT ON COLUMN ctl_proyectos.num_centro IS 'Número de centro del Colaborador (constraint)';
COMMENT ON COLUMN ctl_proyectos.nom_centro IS 'Nombre del centro del Colaborador';
COMMENT ON COLUMN ctl_proyectos.num_gerente IS 'Número de empleado del Gerente (constraint)';
COMMENT ON COLUMN ctl_proyectos.nom_gerente IS 'Nombre del Gerente';
COMMENT ON COLUMN ctl_proyectos.num_proveedor IS 'Nombre del Proveedor (constraint)';
COMMENT ON COLUMN ctl_proyectos.nom_proveedor IS 'Nombre del Proveedor';
COMMENT ON COLUMN ctl_proyectos.num_coordinador IS 'Número de empleado del Coordinador (constraint)';
COMMENT ON COLUMN ctl_proyectos.nom_coordinador IS 'Nombre del Coordinador';
COMMENT ON COLUMN ctl_proyectos.num_nacional IS 'Número de empleado del Nacional (constraint)';
COMMENT ON COLUMN ctl_proyectos.nom_nacional IS 'Nombre del Nacional';
COMMENT ON COLUMN ctl_proyectos.fec_inicio IS 'Fecha y hora de registro del empleado';
COMMENT ON COLUMN ctl_proyectos.fec_promesa IS 'Fecha y hora de registro del empleado';
COMMENT ON COLUMN ctl_proyectos.fec_realfin IS 'Fecha y hora de registro del empleado';
COMMENT ON COLUMN ctl_proyectos.fec_movto IS 'Fecha y hora de primer registro (guardada en automático)';
COMMENT ON COLUMN ctl_proyectos.num_ip IS 'IP de máquina donde se realizó el registro';
COMMENT ON COLUMN ctl_proyectos.num_macaddress IS 'Dirección MAC de máquina donde se realizó el registro';
COMMENT ON COLUMN ctl_proyectos.num_latitud IS 'Coordenada de latitud de ubicación';
COMMENT ON COLUMN ctl_proyectos.num_longitud IS 'Coordenada de longitud de ubicación';
COMMENT ON COLUMN ctl_proyectos.keyx IS 'Indicador automático consecutivo de la tabla (autoincremental) (Primary Key)';
COMMENT ON COLUMN ctl_proyectos.keyx_proyectos_rv IS 'Sale de la tabla ctl_proyectos_rv según nombre del sistema. (Primary Key)';

 --index
CREATE INDEX idx_ctl_proyectos_keyx ON ctl_proyectos (keyx);
CREATE INDEX idx_ctl_proyectos_numerocolaborador ON ctl_proyectos (num_colaborador);
CREATE INDEX idx_ctl_proyectos_nombrecolaborador ON ctl_proyectos (nom_colaborador);
CREATE INDEX idx_ctl_proyectos_numerocentro ON ctl_proyectos (num_centro);
CREATE INDEX idx_ctl_proyectos_nombrecentro ON ctl_proyectos (nom_centro);
CREATE INDEX idx_ctl_proyectos_numerorol ON ctl_proyectos (num_rol);
CREATE INDEX idx_ctl_proyectos_nombrerol ON ctl_proyectos (nom_rol);
CREATE INDEX idx_ctl_proyectos_numerogerente ON ctl_proyectos (num_gerente);
CREATE INDEX idx_ctl_proyectos_nombregerente ON ctl_proyectos (nom_gerente); 
CREATE INDEX idx_ctl_proyectos_nombreproveedor ON ctl_proyectos (nom_proveedor);
CREATE INDEX idx_ctl_proyectos_nombreproyecto ON ctl_proyectos (nom_proyecto);
CREATE INDEX idx_ctl_proyectos_keyx_rv ON ctl_proyectos (keyx_proyectos_rv);

------ ctl_proyectos_rv
-- SELECT * FROM ctl_proyectos_rv;
-- DROP TABLE ctl_proyectos_rv CASCADE;

CREATE TABLE IF NOT EXISTS ctl_proyectos_rv
(
    num_gerente bigint NOT NULL,				-- Se alimenta por la captura
    nom_gerente varchar(60) NOT NULL, 			-- Sale de la tabla cat_gerentes    
    nom_proyecto varchar(100) NOT NULL,			-- Se alimenta por la captura
	des_proyecto character varying(8000) NOT NULL, -- Se alimenta por la captura
    num_coordinador bigint NOT NULL,			-- Sale de la tabla cat_colaboradores
    nom_coordinador varchar(60) NOT NULL,		-- Sale de la tabla cat_coordinadores
    num_nacional bigint NOT NULL,				-- Sale de la tabla cat_nacionales según el número del coordinador
    nom_nacional varchar(60) NOT NULL,			-- Sale de la tabla cat_nacionales según el número del coordinador
    fec_inicio date NOT NULL,					-- Se alimenta por la captura
	fec_promesa date NOT NULL,							-- Se alimenta por la captura
	fec_realfin date, 							-- Se alimenta por la captura
    fec_movto timestamp without time zone NOT NULL DEFAULT now(),
    flg_activo integer NOT NULL DEFAULT 0,
	keyx serial NOT NULL,
	UNIQUE(keyx),
    CONSTRAINT pk_ctl_proyectos_rv PRIMARY KEY (keyx),	
	CONSTRAINT fk_ctl_proyectos_rv_cat_gerentes FOREIGN KEY (num_gerente) REFERENCES cat_gerentes (num_gerente),
	CONSTRAINT fk_ctl_proyectos_rv_cat_coordinadores FOREIGN KEY (num_coordinador) REFERENCES cat_coordinadores (num_coordinador),
	CONSTRAINT fk_ctl_proyectos_rv_cat_nacionales FOREIGN KEY (num_nacional) REFERENCES cat_nacionales (num_nacional)
)
WITHOUT OIDS;


GRANT select, insert, update, delete ON TABLE ctl_proyectos_rv TO sysdesarrollorvia;

COMMENT ON TABLE ctl_proyectos_rv IS 'Datos de empleados que llevaran el desarrollo de un proyecto';
COMMENT ON COLUMN ctl_proyectos_rv.nom_proyecto IS 'Nombre de proyecto al que pertenece el Colaborador';
COMMENT ON COLUMN ctl_proyectos_rv.num_gerente IS 'Número de empleado del Gerente (constraint)';
COMMENT ON COLUMN ctl_proyectos_rv.nom_gerente IS 'Nombre del Gerente';
COMMENT ON COLUMN ctl_proyectos_rv.num_coordinador IS 'Número de empleado del Coordinador (constraint)';
COMMENT ON COLUMN ctl_proyectos_rv.nom_coordinador IS 'Nombre del Coordinador';
COMMENT ON COLUMN ctl_proyectos_rv.num_nacional IS 'Número de empleado del Nacional (constraint)';
COMMENT ON COLUMN ctl_proyectos_rv.nom_nacional IS 'Nombre del Nacional';
COMMENT ON COLUMN ctl_proyectos_rv.fec_inicio IS 'Fecha y hora de inicio de proyecto';
COMMENT ON COLUMN ctl_proyectos_rv.fec_promesa IS 'Fecha y hora promesa de fin de proyecto';
COMMENT ON COLUMN ctl_proyectos_rv.fec_realfin IS 'Fecha y hora fin del proyecto';
COMMENT ON COLUMN ctl_proyectos_rv.fec_movto IS 'Fecha y hora de primer registro (guardada en automático)';
COMMENT ON COLUMN ctl_proyectos_rv.flg_activo IS 'Identificador del proyecto activo o inactivo dentro del proyecto, false = inactivo, true = activo';
COMMENT ON COLUMN ctl_proyectos_rv.keyx IS 'Indicador automático consecutivo de la tabla (autoincremental) (Primary Key)';

 --index
CREATE INDEX idx_ctl_proyectos_rv_keyx ON ctl_proyectos (keyx);
CREATE INDEX idx_ctl_proyectos_rv_numerogerente ON ctl_proyectos (num_gerente);
CREATE INDEX idx_ctl_proyectos_rv_nombregerente ON ctl_proyectos (nom_gerente); 
-----------------------------
-- SELECT * FROM cat_facejpg;
-- DROP TABLE cat_facejpg CASCADE;
CREATE TABLE IF NOT EXISTS cat_facejpg
(
    num_colaborador bigint NOT NULL,
    img_colaborador varchar(200000) NOT NULL,
    fec_movto timestamp without time zone NOT NULL DEFAULT now(),
    keyx serial NOT NULL,
	UNIQUE(num_colaborador),
	CONSTRAINT pk_cat_facejpg PRIMARY KEY (keyx, num_colaborador)
)
WITHOUT OIDS;

GRANT select, insert, update, delete ON TABLE cat_facejpg TO sysdesarrollorvia;

COMMENT ON TABLE cat_facejpg IS 'Datos de los rostros por colaborador';
COMMENT ON COLUMN cat_facejpg.num_colaborador IS 'Número del colaborador';
COMMENT ON COLUMN cat_facejpg.img_colaborador IS 'Imagen del Colabrador';
COMMENT ON COLUMN cat_facejpg.fec_movto IS 'Fecha de inserción del movimiento';
COMMENT ON COLUMN cat_facejpg.keyx IS 'Indicador automático consecutivo de la tabla (autoincremental)';

 --index
CREATE INDEX idx_cat_facejpg_numerocolaborador ON cat_facejpg (num_colaborador);
--CREATE INDEX idx_cat_facejpg_imgcolaborador ON cat_facejpg (img_colaborador);
CREATE INDEX idx_cat_facejpg_keyx ON cat_facejpg (keyx);

-- INSERT INTO cat_facejpg (num_colaborador, img_colaborador) VALUES ('90131303'::bigint, ''::character;

-----------------------------
-- SELECT * FROM cat_faceactividadesjpg;
-- DROP TABLE cat_faceactividadesjpg CASCADE;
CREATE TABLE IF NOT EXISTS cat_faceactividadesjpg
(
    num_colaborador bigint NOT NULL,
    img_colaborador varchar(200000) NOT NULL,
    fec_movto timestamp without time zone NOT NULL DEFAULT now(),
	keyXOrigenProyecto bigint NOT NULL,
    keyx serial NOT NULL,
	UNIQUE(num_colaborador),
	CONSTRAINT pk_cat_faceactividadesjpg PRIMARY KEY (keyx, num_colaborador)
)
WITHOUT OIDS;

GRANT select, insert, update, delete ON TABLE cat_faceactividadesjpg TO sysdesarrollorvia;

COMMENT ON TABLE cat_faceactividadesjpg IS 'Datos de los rostros por colaborador';
COMMENT ON COLUMN cat_faceactividadesjpg.num_colaborador IS 'Número del colaborador';
COMMENT ON COLUMN cat_faceactividadesjpg.img_colaborador IS 'Imagen del Colabrador';
COMMENT ON COLUMN cat_faceactividadesjpg.fec_movto IS 'Fecha de inserción del movimiento';
COMMENT ON COLUMN cat_faceactividadesjpg.keyXOrigenProyecto IS 'Indicador del keyx origen del proyecto o activida que se generó';
COMMENT ON COLUMN cat_faceactividadesjpg.keyx IS 'Indicador automático consecutivo de la tabla (autoincremental)';

 --index
CREATE INDEX idx_cat_faceactividadesjpg_numerocolaborador ON cat_faceactividadesjpg (num_colaborador);
--CREATE INDEX idx_cat_faceactividadesjpg_imgcolaborador ON cat_faceactividadesjpg (img_colaborador);
CREATE INDEX idx_cat_faceactividadesjpg_keyx ON cat_faceactividadesjpg (keyx);

-- INSERT INTO cat_facejpg (num_colaborador, img_colaborador) VALUES ('90131303'::bigint, ''::character;

-------------------------------------------- métricas por lenguaje --------------------------------------------------
-- Crear la tabla (si aún no existe)
-- DROP TABLE ctl_metricas_por_lenguaje CASCADE;
-- SELECT * FROM ctl_metricas_por_lenguaje;
CREATE TABLE IF NOT EXISTS ctl_metricas_por_lenguaje (
    nom_lenguaje VARCHAR(50) CHECK (UPPER(nom_lenguaje) = nom_lenguaje) NOT NULL,
	tip_actividad VARCHAR(15) CHECK (UPPER(tip_actividad) = tip_actividad) NOT NULL,
    migracion_meta INT NOT NULL,	
    vulnerabilidades_meta INT,
	fec_movto timestamp without time zone NOT NULL DEFAULT now(),
    keyx serial NOT NULL,
	CONSTRAINT pk_ctl_metricas_por_lenguaje PRIMARY KEY (keyx)
)WITHOUT OIDS;

GRANT select, insert, update, delete ON TABLE ctl_metricas_por_lenguaje TO syscheckattendancebyface;

COMMENT ON TABLE ctl_metricas_por_lenguaje IS 'Datos de las métricas por lenguaje que debe cumplirse por colaborador';
COMMENT ON COLUMN ctl_metricas_por_lenguaje.nom_lenguaje IS 'Nombre del lenguaje de programación';
COMMENT ON COLUMN ctl_metricas_por_lenguaje.tip_actividad IS 'Tipo de actividad DESARROLLO o PRUEBAS';
COMMENT ON COLUMN ctl_metricas_por_lenguaje.migracion_meta IS 'Número de meta de las migraciones';
COMMENT ON COLUMN ctl_metricas_por_lenguaje.vulnerabilidades_meta IS 'Número de meta de las vulnerabilidades';
COMMENT ON COLUMN ctl_metricas_por_lenguaje.fec_movto IS 'Fecha de inserción del movimiento';
COMMENT ON COLUMN ctl_metricas_por_lenguaje.keyx IS 'Indicador del keyx secuencial';

 --index
CREATE INDEX idx_ctl_metricas_por_lenguaje_nom_lenguaje ON ctl_metricas_por_lenguaje (nom_lenguaje);
CREATE INDEX idx_ctl_metricas_por_lenguaje_tip_actividad ON ctl_metricas_por_lenguaje (tip_actividad);
CREATE INDEX idx_ctl_metricas_por_lenguaje_migracion_meta ON ctl_metricas_por_lenguaje (migracion_meta);
CREATE INDEX idx_ctl_metricas_por_lenguaje_vulnerabilidades_meta ON ctl_metricas_por_lenguaje (vulnerabilidades_meta);
CREATE INDEX idx_ctl_metricas_por_lenguaje_fec_movto ON ctl_metricas_por_lenguaje (fec_movto);
CREATE INDEX idx_ctl_metricas_por_lenguaje_keyx ON ctl_metricas_por_lenguaje (keyx);


-- Insertar los datos
-- 
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('PHP', 'DESARROLLO', 96, 176);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('JQUERY', 'DESARROLLO',57, 40);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('SQL', 'DESARROLLO', 298, 298);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('JAVA', 'DESARROLLO', 66, 279);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('C', 'DESARROLLO', 132, 224);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('CSHARP', 'DESARROLLO', 62, 62);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('CPP', 'DESARROLLO', 132, 224);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('PYTHON', 'DESARROLLO', 71, 63);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('CODEIGNITER', 'DESARROLLO', 260, 260);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('ANGULAR', 'DESARROLLO', 120, 120);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('COLDFUSION', 'DESARROLLO', 43, 46);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('JAVASCRIPT', 'DESARROLLO', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('TYPESCRIPT', 'DESARROLLO', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('VB', 'DESARROLLO', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('RUBY', 'DESARROLLO', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('SWIFT', 'DESARROLLO', 50, 50);-- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('GO', 'DESARROLLO', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('PERL', 'DESARROLLO', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('RUST', 'DESARROLLO', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('KOTLIN', 'DESARROLLO', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('SCALA', 'DESARROLLO', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('PHP', 'PRUEBAS', 54, 95); 
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('JQUERY', 'PRUEBAS', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('SQL', 'PRUEBAS', 340, 40);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('JAVA', 'PRUEBAS', 173, 384);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('C', 'PRUEBAS', 205, 166);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('CSHARP', 'PRUEBAS', 131, 131);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('CPP', 'PRUEBAS', 205, 166);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('PYTHON', 'PRUEBAS', 51, 36);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('CODEIGNITER', 'PRUEBAS', 50, 50);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('ANGULAR', 'PRUEBAS', 113, 113);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('COLDFUSION', 'PRUEBAS', 50, 69);
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('JAVASCRIPT', 'PRUEBAS', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('TYPESCRIPT', 'PRUEBAS', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('VB', 'PRUEBAS', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('RUBY', 'PRUEBAS', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('SWIFT', 'PRUEBAS', 50, 50);-- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('GO', 'PRUEBAS', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('PERL', 'PRUEBAS', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('RUST', 'PRUEBAS', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('KOTLIN', 'PRUEBAS', 50, 50); -- No se tiene se define 50
INSERT INTO ctl_metricas_por_lenguaje (nom_lenguaje, tip_actividad, migracion_meta, vulnerabilidades_meta) VALUES('SCALA', 'PRUEBAS', 50, 50); -- No se tiene se define 50



-- Insertar los datos
INSERT INTO metadatos (lenguaje, migracion_meta, vulnerabilidades_meta)
VALUES
    ('PHP', 96, 176),
    ('jQuery', 57, 40),
    ('SQL', 298, 279),
    -- ... (continuar con los demás lenguajes y valores)
    ('Scala', 71, 63);