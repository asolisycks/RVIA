-- Type: typ_metricas

-- DROP TYPE IF EXISTS public.typ_metricas;

CREATE TYPE public.typ_metricas AS
(
	mig_meta integer,
	vul_meta integer
);