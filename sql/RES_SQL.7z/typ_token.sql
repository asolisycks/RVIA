-- Type: typ_token

-- DROP TYPE IF EXISTS public.typ_token CASCADE;

CREATE TYPE public.typ_token AS
(
	key_token character varying,
	fec_expira timestamp
);

ALTER TYPE public.typ_token
    OWNER TO syscheckattendancebyface;
