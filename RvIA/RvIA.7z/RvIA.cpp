// RvIA.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//

#include "CIA.hpp"

//void calcular(int totalOcurrencias, int ocurrenciasPorSemanaPorColaborador, int numeroDeColaboradores) {
//    // Ajustar las ocurrencias por semana para tener en cuenta solo 5 días hábiles
//    int totalOcurrenciasPorSemana = (ocurrenciasPorSemanaPorColaborador * numeroDeColaboradores * 5) / 7;
//     
//
//
//    std::cout << "Total de ocurrencias por semana 5 días: " << (ocurrenciasPorSemanaPorColaborador * numeroDeColaboradores * 5) << std::endl;
//    std::cout << "Total de ocurrencias por semana 5 días entre 7: " << (ocurrenciasPorSemanaPorColaborador * numeroDeColaboradores * 5) / 7 << std::endl;
//    std::cout << "Total de ocurrencias por semana: " << totalOcurrenciasPorSemana << std::endl;
//
//    double semanasNecesarias = static_cast<double>(totalOcurrencias) / totalOcurrenciasPorSemana;
//
//    // Redondear hacia arriba
//    semanasNecesarias = std::ceil(semanasNecesarias);
//
//    double diasNecesarios = semanasNecesarias * 7;
//    double mesesNecesarios = semanasNecesarias / 4.34524;
//    double anosNecesarios = semanasNecesarias / 52.1775;
//
//    //// Redondear hacia arriba
//    //diasNecesarios = std::ceil(diasNecesarios);
//
//    //// Redondear hacia arriba
//    //mesesNecesarios = std::ceil(mesesNecesarios);
//
//    //// Redondear hacia arriba
//    //anosNecesarios = std::ceil(anosNecesarios);
//
//    std::cout << "Se necesitarán aproximadamente " << semanasNecesarias << " semanas, o " << diasNecesarios << " días, o " << mesesNecesarios << " meses, o " << anosNecesarios << " años para atender las " << totalOcurrencias << " ocurrencias." << std::endl;
//
//    calcularFechaFinal((int)diasNecesarios);
//
//}



//void calcular(int totalOcurrencias, int ocurrenciasPorSemanaPorColaborador) 
//{
//    int diasLaborales = 5;
//
//    int personasNecesarias = std::ceil(static_cast<double>(totalOcurrencias) / ocurrenciasPorSemanaPorColaborador);
//    double ocurrenciasPorDia = static_cast<double>(ocurrenciasPorSemanaPorColaborador) / diasLaborales;
//    double tiempoExtra = (totalOcurrencias % ocurrenciasPorSemanaPorColaborador) / ocurrenciasPorDia;
//    //// Redondear hacia arriba
//    //diasNecesarios = std::ceil(diasNecesarios);
//
//    //// Redondear hacia arriba
//    //mesesNecesarios = std::ceil(mesesNecesarios);
//
//    //// Redondear hacia arriba
//    //anosNecesarios = std::ceil(anosNecesarios);
//
//    std::cout << "Se necesitarán aproximadamente " << personasNecesarias << " semanas, o " << diasNecesarios << " días, o " << mesesNecesarios << " meses, o " << anosNecesarios << " años para atender las " << totalOcurrencias << " ocurrencias." << std::endl;
//
//    calcularFechaFinal((int)diasNecesarios);
//
//}

// Estructura para almacenar la información del token
struct TokenInfo
{
	std::time_t expiryTime;
};

// Mapa para almacenar los tokens generados
std::map<std::string, TokenInfo> tokens;

static bool verificarToken(std::string token)
{
	std::time_t now = std::time(0);
	if (tokens.count(token) > 0 && tokens[token].expiryTime > now)
	{
		return true;
	}
	else
	{
		return false;
	}
}

static void validateParameters(std::string &sRutaProyecto, std::string &sLenguaje, std::string &sTipoMigracion, std::string &sNumColaboradores);
static void validateParametersAll(std::string& sRutaProyecto, std::string& sTipoMigracion, std::string& sNumColaboradores);
static int obtenerOcurrencias(const std::string& sLenguaje, const std::string& sTipoDeMigracion);
static std::map<std::string, int> obtenerMetaSemanalMigVul(const std::vector<std::string>& vcLenguajes, const std::string& sTipoDeMigracion);
static void recorrerMapa(const std::map<std::string, int>& mapOcurrencias);

int main(int argc, char* argv[])
{
	int  iTecla				= 0;
	int  iTotalArchivos		= 0;
	int  l					= 0;
	int  iObsoleto			= 0;
	int  iSentencias		= 0;
	int  iTotalSenObs		= 0;
	int  iNumeroOcurrencias	= 0;
	bool bCiclo				= true;
	bool bContinuar			= false;

	char cPath[MAX_PATH]			= { 0 };
	char cArmarTotales[MAX_PATH]	= { 0 };
	char cArmarBito[MAX_PATH]		= { 0 };
	char cArmarSentencias[MAX_PATH] = { 0 };
	char cArmarObsoleto[MAX_PATH]	= { 0 };
	char cArmarFinProy[MAX_PATH]	= { 0 };

	std::vector<std::string> vcLenguajes;
	vcLenguajes.clear();

	//Función para crear un archivo directorio si no existe
	std::filesystem::create_directory("c:\\sys");
	std::filesystem::create_directory("c:\\sys\\mem");
	std::filesystem::create_directory("c:\\sys\\progs");
	std::filesystem::create_directory("c:\\sys\\progs\\parse");
	std::filesystem::create_directory("c:\\sys\\progs\\parse\\bito");

	system("cls");
	//system("chcp 936");

	std::locale::global(std::locale("es_MX.UTF8"));
	setlocale(LC_ALL, "es_MX.UTF8");
	
	std::string sRutaProyecto;
	std::string sLenguaje;
	std::string sTipoDeMigracion;
	std::string sNumeroOcurrencias;
	std::string sNumeroDeColaboradores;
	int iNumeroDeColaboradores = 0;

	//C:\temp\bito\uno php mig 1
	CIA objCIA;

	if (argc == 2 && ( strcmp(argv[1], "-v") == 0 || strcmp(argv[1], "-V") == 0 ) )
	{
		objCIA.printProgramInfo();
		return 1;
	}
	//else if (argc == 2 && (strcmp(argv[1], "-c") == 0 || strcmp(argv[1], "-C") == 0 ) )
	//{	
	//	//Se solicitará la siguiente información:
	//	//1. Ruta del proyecto
	//	//2. Lenguaje
	//	//3. Tipo de migración (mig o vul)
	//	//4. Número de colaboradores
	//	//Crea el metodo de validación de los parámetros de entrada y no permitas continuar hasta que sean correctos.
	//	//Si los parámetros son correctos, se ejecutará el proceso de IA con BITO.
	//	//Si los parámetros son incorrectos, se mostrará un mensaje de error y se terminará la ejecución del programa.

	//	validateParameters(sRutaProyecto, sLenguaje, sTipoDeMigracion, sNumeroDeColaboradores);

	//	// Obtiene la ruta del proyecto
	//	memset(cPath, 0, sizeof(cPath));
	//	sprintf_s(cPath, sizeof(cPath), "%s", sRutaProyecto.c_str());
	//}
	//else if (argc == 4 && (strcmp(argv[1], "-t") == 0 || strcmp(argv[1], "-T") == 0))
	else if (argc == 5)
	{
		//for (int i = 0; i < 10; i++)
		//{
		//	objCIA.setColor(i);
		//	std::cout << i << "Espere, Obtiene totales.\n";
		//}
		//getchar();
		//exit(0);

		//Se solicitará la siguiente información:
		//1. Ruta del proyecto
		//2. Tipo de migración (mig o vul)
		//3. Número de colaboradores
		//Crea el metodo de validación de los parámetros de entrada y no permitas continuar hasta que sean correctos.
		//Si los parámetros son correctos, se ejecutará el proceso de IA con BITO.
		//Si los parámetros son incorrectos, se mostrará un mensaje de error y se terminará la ejecución del programa.
		//validateParametersAll(sRutaProyecto, sTipoDeMigracion, sNumeroDeColaboradores);

		// Obtiene la ruta del proyecto
		memset(cPath, 0, sizeof(cPath));
		sprintf_s(cPath, sizeof(cPath), "%s", argv[1]);

		//Obtiene el tipo de migración
		sTipoDeMigracion = argv[2];

		//validar que el tipo de migración sea solo mig o vul
		if (sTipoDeMigracion.compare("mig") != 0 && sTipoDeMigracion.compare("vul") != 0)
		{
			std::cerr << "Error: Por favor captura solo mig o vul. Ejemplo (mig o vul)" << std::endl;
			return 1;
		}

		//Obtiene el número de colaboradores que participan en el proyecto.
		iNumeroDeColaboradores = atoi(argv[3]);

		//validar que el número de colaboradores sea solo números naturales
		if (iNumeroDeColaboradores <= 0)
		{
			std::cerr << "Error: Solo se permiten números. Ejemplo (1, 2, 3, 4, 5, etc...)" << std::endl;
			return 1;
		}

		// Obtiene la ruta del archivo a generar
		memset(cArmarTotales, 0, sizeof(cArmarTotales));
		sprintf_s(cArmarTotales, sizeof(cArmarTotales), "%s\\%s", cPath, "totales.txt");
		// Elimina el archivo existente
		std::filesystem::remove(cArmarTotales);

		// Obtiene la ruta del archivo a generar bito.csv
		memset(cArmarBito, 0, sizeof(cArmarBito));
		sprintf_s(cArmarBito, sizeof(cArmarBito), "%s\\%s", cPath, "bito.csv");
		// Elimina el archivo existente
		std::filesystem::remove(cArmarBito);

		// Obtiene la ruta del archivo a generar sentencias.csv
		memset(cArmarSentencias, 0, sizeof(cArmarSentencias));
		sprintf_s(cArmarSentencias, sizeof(cArmarSentencias), "%s\\%s", cPath, "sentencias.csv");
		// Elimina el archivo existente
		std::filesystem::remove(cArmarSentencias);

		// Obtiene la ruta del archivo a generar obsoleto.csv
		memset(cArmarObsoleto, 0, sizeof(cArmarObsoleto));
		sprintf_s(cArmarObsoleto, sizeof(cArmarObsoleto), "%s\\%s", cPath, "obsoleto.csv");
		// Elimina el archivo existente
		std::filesystem::remove(cArmarObsoleto);

		// Obtiene la ruta del archivo a generar finProyecto.csv
		memset(cArmarFinProy, 0, sizeof(cArmarFinProy));
		sprintf_s(cArmarFinProy, sizeof(cArmarFinProy), "%s\\%s", cPath, "finProyecto.csv");
		// Elimina el archivo existente
		std::filesystem::remove(cArmarFinProy);

		// Lee el token y su tiempo de expiración de un archivo
		std::string token;
		std::time_t expiryTime;
		std::ifstream tokenFile("c:\\sys\\progs\\parse\\bito\\token.txt");

		if (tokenFile.is_open())
		{
			getline(tokenFile, token);
			tokenFile >> expiryTime;
			tokenFile.close();
			tokens[token] = { expiryTime };
		}
		else
		{
			std::cout << "No se pudo validar el token.\n";
			return ERROR_INVALID_TOKEN;
		}

		// Inicia el reloj
		std::clock_t start_time = std::clock();

		// Verifica el token
		if (verificarToken(token))
		{
			//const int total = 100;
			//for (int i = 0; i <= total; ++i) {
			//	std::cout << "\rProgreso: " << i << "/" << total << std::flush;
			//	std::this_thread::sleep_for(std::chrono::milliseconds(100));
			//}
			//std::cout << std::endl;

			std::cout << "-----------------------------------------------------" << std::endl;
			std::cout << " Herramienta de Migración y Vulnerabilidades con IA  " << std::endl;
			std::cout << "_____________________________________________________" << std::endl;
			std::cout << std::endl;
			Sleep(2000);

			objCIA.setColor(2); // Verde
			std::cout << "Espere, Obtiene totales.\n";
			objCIA.obtieneTotales(cPath, cArmarTotales, vcLenguajes);

			if (vcLenguajes.size() > 0)
			{
				std::filesystem::remove(cArmarTotales);

				objCIA.setColor(7); // Blanco
				std::cout << "Espere, Obtiene sentencias.\n";
				std::map<std::string, int> mapSentencias = objCIA.obtieneSentenciasSQLEnMapa(cPath, cArmarSentencias);

				//iSentencias = objCIA.obtieneSentenciasSQLEnVector(cPath, cArmarSentencias);

				//recorrerMapa(mapSentencias);

				objCIA.setColor(4); // Rojo
				std::cout << "Espere, Obtiene funciones obsoletas.\n";
				std::map<std::string, int> mapDeprecated = objCIA.obtieneFuncionesObsoletasEnMapa(cPath, cArmarObsoleto);
				//iObsoleto = objCIA.obtieneFuncionesObsoletasEnVector(cPath, cArmarObsoleto, vcLenguajes);

				//recorrerMapa(mapDeprecated);

				objCIA.setColor(2); // Verde
				std::cout << "Espere, Obtiene IA con BITO.\n";
				objCIA.ejecutaProcesoIA(cPath);
				std::cout << "Gracias por esperar, se finalizó el proceso con IA BITO.\n";

				objCIA.setColor(7); // Blanco
				sLenguaje = "." + sLenguaje;
				iTotalArchivos = objCIA.contarArchivosEnVector(cPath, vcLenguajes);
				std::cout << "Total de archivos encontrados [ " << iTotalArchivos << " ] de " << sLenguaje << std::endl;

				//validar el tipo de lenguaje que entro por parámetro y si el tipo de migración es mig o vul.
				//iNumeroOcurrencias = obtenerOcurrencias(sLenguaje, sTipoDeMigracion);
				auto mapMetaSemanal = obtenerMetaSemanalMigVul(vcLenguajes, sTipoDeMigracion);

				//recorrerMapa(mapMetaSemanal);

				std::cout << "Espere, Calcula fecha fin proyecto.\n";
				int iRet = objCIA.calcularFinDeProyectoMap(mapMetaSemanal, mapSentencias, mapDeprecated, cPath, iTotalArchivos, iNumeroDeColaboradores);

				//std::cout << "Espere, Calcula fecha fin proyecto.\n";
				//objCIA.calcularFechaFinProyectoCaptura(cPath, (char*)sLenguaje.c_str(), iTotal, iNumeroDeColaboradores, iNumeroOcurrencias, iTotalArchivos);

				objCIA.setColor(7); // Blanco
				std::cout << "ESPERE, SE GENERA ARCHIVO DE EXCEL.\n";
				objCIA.pathFileCreatedCSV(cPath);
				objCIA.setColor(7); // Verde
				std::cout << "PROCESO FINALIZADO. PRESIONA CUALQUIER TECLA PARA FINALIZAR..." << std::endl;
				iTecla = _getch();
				//objCIA.menu();

				//Por mientras se comenta aquí.
				vcLenguajes.clear();
				mapMetaSemanal.clear();
				mapSentencias.clear();
				mapDeprecated.clear();
			}
			else
			{
				std::cout << "No se encontraron archivos a procesar." << std::endl;
				return ERROR_FILE_NOT_FOUND;
			}
		}
		else
		{
			std::cout << "El token no es válido o ha expirado.\n";
			return ERROR_INVALID_TOKEN;
		}

		std::cout << "" << std::endl;
		double execution_time = (std::clock() - start_time) / (double)CLOCKS_PER_SEC;
		std::cout << "Tiempo de ejecución," << execution_time << " segundos" << std::endl;

		return 0;
	}
	else if (argc != 6)
	{
		std::cout << "-----------------------------------\n";
		//std::cout << "Ejemplo de uso A) : " << argv[0] << " -v\n";
		//std::cout << "Ejemplo de uso : " << argv[0] << " -t\n";
		std::cout << "Ejemplo de uso : " << argv[0] << " <Ruta de proyecto> <mig|vul> <numeroDeColaboradores>\n";
		//std::cout << "Ejemplo : " << argv[0] << " c:\\temp\\proyecto php mig|vul 1\n";
		std::cout << "-----------------------------------\n";
		return 1;
	}
	//else if (argc == 6)
	//{
	//	// Obtiene la ruta del proyecto
	//	memset(cPath, 0, sizeof(cPath));
	//	sprintf_s(cPath, sizeof(cPath), "%s", argv[1]);

	//	sLenguaje = argv[2];

	//	//validar que el lenguaje sea solo letras
	//	if (!objCIA.soloCaracteres(sLenguaje))
	//	{
	//		std::cout << "Error: Por favor captura solo la extensión del lenguaje. Ejemplo (PHP, CPP, C, JAVA, <TODOS>, Etc...)" << std::endl;
	//		return 1;
	//	}

	//	sTipoDeMigracion = argv[3];

	//	//validar que el tipo de migración sea solo mig o vul
	//	if (sTipoDeMigracion.compare("mig") != 0 && sTipoDeMigracion.compare("vul") != 0)
	//	{
	//		std::cout << "Error: Por favor captura solo mig o vul. Ejemplo (mig o vul)" << std::endl;
	//		return 1;
	//	}

	//	sNumeroDeColaboradores = argv[4];
	//	
	//	//validar que el número de colaboradores sea solo números naturales
	//	if (!objCIA.esNumeroNatural(sNumeroDeColaboradores))
	//	{
	//		std::cout << "Error: Por favor captura solo numeros. Ejemplo (1, 2, 3, 4, 5, etc...)" << std::endl;
	//		return 1;
	//	}
	//}
	else
	{
		std::cout << "Uso: " << argv[0] << " <Ruta de proyecto> <Lenguaje> <migracion|vulnerabilidad> <numeroDeColaboradores>\n";
		return 1;
	}

	// Obtiene la ruta del archivo a generar
	memset(cArmarTotales, 0, sizeof(cArmarTotales));
	sprintf_s(cArmarTotales, sizeof(cArmarTotales), "%s\\%s", cPath, "totales.txt");
	// Elimina el archivo existente
	std::filesystem::remove(cArmarTotales);

	// Obtiene la ruta del archivo a generar bito.csv
	memset(cArmarBito, 0, sizeof(cArmarBito));
	sprintf_s(cArmarBito, sizeof(cArmarBito), "%s\\%s", cPath, "bito.csv");
	// Elimina el archivo existente
	std::filesystem::remove(cArmarBito);

	// Obtiene la ruta del archivo a generar sentencias.csv
	memset(cArmarSentencias, 0, sizeof(cArmarSentencias));
	sprintf_s(cArmarSentencias, sizeof(cArmarSentencias), "%s\\%s", cPath, "sentencias.csv");
	// Elimina el archivo existente
	std::filesystem::remove(cArmarSentencias);

	// Obtiene la ruta del archivo a generar obsoleto.csv
	memset(cArmarObsoleto, 0, sizeof(cArmarObsoleto));
	sprintf_s(cArmarObsoleto, sizeof(cArmarObsoleto), "%s\\%s", cPath, "obsoleto.csv");
	// Elimina el archivo existente
	std::filesystem::remove(cArmarObsoleto);

	// Obtiene la ruta del archivo a generar finProyecto.csv
	memset(cArmarFinProy, 0, sizeof(cArmarFinProy));
	sprintf_s(cArmarFinProy, sizeof(cArmarFinProy), "%s\\%s", cPath, "finProyecto.csv");
	// Elimina el archivo existente
	std::filesystem::remove(cArmarFinProy);

	//validar el tipo de lenguaje que entro por parámetro y si el tipo de migración es mig o vul.
	iNumeroOcurrencias = obtenerOcurrencias(sLenguaje, sTipoDeMigracion);
	
	if (!objCIA.esNumeroNatural(sNumeroDeColaboradores))
	{
		std::cout << "Error: Por favor captura solo numeros. Ejemplo (1, 2, 3, 4, 5, etc...)" << std::endl;
		return 1;
	}

	//Convertir sNumeroDeColaboradores a int
	iNumeroDeColaboradores = std::stoi(sNumeroDeColaboradores);

	// Lee el token y su tiempo de expiración de un archivo
	std::string token;
	std::time_t expiryTime;
	std::ifstream tokenFile("c:\\sys\\progs\\parse\\bito\\token.txt");

	if (tokenFile.is_open())
	{
		getline(tokenFile, token);
		tokenFile >> expiryTime;
		tokenFile.close();
		tokens[token] = { expiryTime };
	}
	else
	{
		std::cout << "No se pudo validar el token.\n";
		return 1;
	}

	// Inicia el reloj
	std::clock_t start_time = std::clock();

	// Verifica el token
	if (verificarToken(token))
	{
		objCIA.menu();
		while (bCiclo)
		{
			if (_kbhit())
			{
				iTecla = _getch();

				if (iTecla == 0 || iTecla == 224)
				{
					iTecla = _getch();
				}

				switch (iTecla)
				{
				case 59: // F1
					objCIA.setColor(2); // Verde
					std::cout << "Espere, Obtiene totales.\n";
					objCIA.obtieneTotales(cPath, cArmarTotales, vcLenguajes);
					objCIA.setColor(7); // Blanco
					Sleep(3000);
					std::cout << "Proceso finalizado. Presiona cualquier tecla para continuar..." << std::endl;
					iTecla = _getch();
					objCIA.menu();
					break;
				case 60: // F2
					objCIA.setColor(4); // Rojo
					objCIA.obtieneSentenciasSQL(cPath, cArmarSentencias, (char*)"");
					objCIA.setColor(7); // Blanco
					std::cout << "Proceso finalizado. Presiona cualquier tecla para continuar..." << std::endl;
					iTecla = _getch();
					objCIA.menu();
					break;
				case 61: // F3
					objCIA.setColor(1); // Azul
					objCIA.obtieneFuncionesObsoletas(cPath, cArmarObsoleto, (char*)"");
					objCIA.setColor(7); // Blanco
					std::cout << "Proceso finalizado. Presiona cualquier tecla para continuar..." << std::endl;
					iTecla = _getch();
					objCIA.menu();
					break;
					//case 62: // F4
					//    //objCIA.setColor(5); // Morado
					//    objCIA.setColor(1); // Azul
					//    objCIA.obtieneBITO(cPath, cArmarBito);
					//    objCIA.setColor(7); // Blanco
					//    break;
				case 62: // F4
					objCIA.setColor(6); // Amarillo

					std::cout << "Por favor, introduce el lenguaje a calcular. Ejemplo (PHP, CPP, C, JAVA, Etc...): ";
					std::cin >> sLenguaje;
					if (!objCIA.soloCaracteres(sLenguaje))
					{
						std::cout << "Error: Por favor captura solo la extensión del lenguaje. Ejemplo (PHP, CPP, C, JAVA, Etc...)" << std::endl;
						continue;
					}
					//objCIA.calcularFechaFinProyectoCaptura(sLenguaje);
					objCIA.setColor(7); // Blanco
					break;
				case 63: // F5
					objCIA.setColor(9); // Azul claro
					do
					{
						std::cout << "Por favor, introduce el lenguaje a procesar. Ejemplo (PHP, CPP, C, JAVA): ";
						std::cin >> sLenguaje;
						if (!objCIA.soloCaracteres(sLenguaje))
						{
							std::cout << "Error: Por favor captura solo la extensión del lenguaje. Ejemplo (PHP, CPP, C, JAVA)" << std::endl;
							continue;
						}
						else
						{
							bContinuar = objCIA.validateExtension(sLenguaje);
						}
					} while (bContinuar == false);

					if (bContinuar)
					{
						sLenguaje = "." + sLenguaje;
						iTotalArchivos = objCIA.contarArchivos(cPath, sLenguaje);
						std::cout << "Total de archivos encontrados [ " << iTotalArchivos << " ] de " << sLenguaje << std::endl;
						std::cout << "Proceso finalizado. Presiona cualquier tecla para continuar..." << std::endl;
						l = _getch();
						objCIA.menu();
					}

					objCIA.setColor(7); // Blanco
					break;
				case 64: // F6
					//objCIA.setColor(6); // Amarillo

					//std::cout << "Espere, Obtiene totales.\n";
					//objCIA.obtieneTotales(cPath, cArmarTotales);

					//objCIA.setColor(9); // Azul claro
					//std::cout << "Espere, Obtiene sentencias.\n";
					//iSentencias = objCIA.obtieneSentenciasSQL(cPath, cArmarSentencias, (char*)sLenguaje.c_str());

					//objCIA.setColor(3); // Cyan
					//std::cout << "Espere, Obtiene funciones obsoletas.\n";
					//iObsoleto = objCIA.obtieneFuncionesObsoletas(cPath, cArmarObsoleto, (char*)sLenguaje.c_str());

					//iTotal = iSentencias + iObsoleto;
					//std::cout << "Total de sentencias y funciones obsoletas encontradas [ " << iTotal << " ] de PHP" << std::endl;

					objCIA.setColor(2); // Verde
					std::cout << "Espere, Obtiene IA con BITO.\n";
					objCIA.ejecutaProcesoIA(cPath);
					std::cout << "Gracias por esperar, se finalizó el proceso con IA BITO.\n";

					//objCIA.setColor(5); // Morado

					//sLenguaje = "." + sLenguaje;
					//iTotalArchivos = objCIA.contarArchivos(cPath, sLenguaje);
					//std::cout << "Total de archivos encontrados [ " << iTotalArchivos << " ] de " << sLenguaje << std::endl;

					//std::cout << "Espere, Calcula fecha fin proyecto.\n";
					//objCIA.calcularFechaFinProyectoCaptura(cPath, (char*)sLenguaje.c_str(), iTotal, iNumeroDeColaboradores, iNumeroOcurrencias, iTotalArchivos);
					//
					//objCIA.setColor(1); // Azul
					//std::cout << "Espere, Se genera archivo de Excel.\n";
					//objCIA.pathFileCreatedCSV(cPath);
					objCIA.setColor(7); // Blanco    
					std::cout << "Proceso finalizado. Presiona cualquier tecla para continuar..." << std::endl;
					iTecla = _getch();
					objCIA.menu();
					break;
				case 67: // F9
					objCIA.setColor(11); // Cyan claro
					objCIA.printProgramInfo();
					objCIA.setColor(7); // Blanco
					break;
				case 27: // Escape
					objCIA.setColor(12); // Rojo claro
					std::cout << "Muchas gracias por utilizar nuestra App, regrese pronto ;).\n";
					objCIA.setColor(7); // Blanco
					exit(0);
					break;
				default:
					break;
				}
			}
		}

	}
	else
	{
		std::cout << "El token no es válido o ha expirado.\n";
		return 1;
	}

	std::cout << "" << std::endl;
	double execution_time = (std::clock() - start_time) / (double)CLOCKS_PER_SEC;
	std::cout << "Tiempo de ejecución," << execution_time << " segundos" << std::endl;
		
	return 0;
}

static int obtenerOcurrencias(const std::string& sLenguaje, const std::string& sTipoDeMigracion)
{
	std::string sNumeroOcurrencias;
	int iNumeroOcurrencias = 0;

	//validar el tipo de lenguaje que entro por parámetro y si el tipo de migración es mig o vul.
	if (sLenguaje.compare("php") == 0 || sLenguaje.compare("PHP") == 0)
	{
		if (sTipoDeMigracion.compare("mig") == 0)
		{
			// convertir a entero el numero de ocurrencias
			sNumeroOcurrencias = std::to_string(PHP_MIGRACION_META);
		}
		else if (sTipoDeMigracion.compare("vul") == 0)
		{
			sNumeroOcurrencias = std::to_string(PHP_VULNERABILIDADES_META);
		}
	}
	else if (sLenguaje.compare("cpp") == 0 || sLenguaje.compare("CPP") == 0)
	{
		if (sTipoDeMigracion.compare("mig") == 0)
		{
			sNumeroOcurrencias = std::to_string(CPP_MIGRACION_META);
		}
		else if (sTipoDeMigracion.compare("vul") == 0)
		{
			sNumeroOcurrencias = std::to_string(CPP_VULNERABILIDADES_META);
		}
	}
	else if (sLenguaje.compare("C") == 0 || sLenguaje.compare("c") == 0)
	{
		if (sTipoDeMigracion.compare("mig") == 0)
		{
			sNumeroOcurrencias = std::to_string(C_MIGRACION_META);
		}
		else if (sTipoDeMigracion.compare("vul") == 0)
		{
			sNumeroOcurrencias = std::to_string(C_VULNERABILIDADES_META);
		}
	}
	else if (sLenguaje.compare("JAVA") == 0 || sLenguaje.compare("java") == 0)
	{
		if (sTipoDeMigracion.compare("mig") == 0)
		{
			sNumeroOcurrencias = std::to_string(JAVA_MIGRACION_META);
		}
		else if (sTipoDeMigracion.compare("vul") == 0)
		{
			sNumeroOcurrencias = std::to_string(JAVA_VULNERABILIDADES_META);
		}
	}
	else if (sLenguaje.compare("JS") == 0 || sLenguaje.compare("js") == 0)
	{
		if (sTipoDeMigracion.compare("mig") == 0)
		{
			sNumeroOcurrencias = std::to_string(JAVASCRIPT_MIGRACION_META);
		}
		else if (sTipoDeMigracion.compare("vul") == 0)
		{
			sNumeroOcurrencias = std::to_string(JAVASCRIPT_VULNERABILIDADES_META);
		}
	}
	else if (sLenguaje.compare("CS") == 0 || sLenguaje.compare("cs") == 0)
	{
		if (sTipoDeMigracion.compare("mig") == 0)
		{
			sNumeroOcurrencias = std::to_string(CSHARP_MIGRACION_META);
		}
		else if (sTipoDeMigracion.compare("vul") == 0)
		{
			sNumeroOcurrencias = std::to_string(CSHARP_VULNERABILIDADES_META);
		}
	}
	else if (sLenguaje.compare("PY") == 0 || sLenguaje.compare("py") == 0)
	{
		if (sTipoDeMigracion.compare("mig") == 0)
		{
			sNumeroOcurrencias = std::to_string(PYTHON_MIGRACION_META);
		}
		else if (sTipoDeMigracion.compare("vul") == 0)
		{
			sNumeroOcurrencias = std::to_string(PYTHON_VULNERABILIDADES_META);
		}
	}
	else if (sLenguaje.compare("TS") == 0 || sLenguaje.compare("ts") == 0)
	{
		if (sTipoDeMigracion.compare("mig") == 0)
		{
			sNumeroOcurrencias = std::to_string(TYPESCRIPT_MIGRACION_META);
		}
		else if (sTipoDeMigracion.compare("vul") == 0)
		{
			sNumeroOcurrencias = std::to_string(TYPESCRIPT_VULNERABILIDADES_META);
		}
	}
	else
	{
		std::cout << "Error: Por favor captura solo la extensión del lenguaje. Ejemplo (PHP, CPP, TS, JS, C, JAVA, Etc...)" << std::endl;
		return 1;
	}

	//convertir sNumeroOcurrencias a int
	iNumeroOcurrencias = std::stoi(sNumeroOcurrencias);

	return iNumeroOcurrencias;
}


static std::map<std::string, int> obtenerMetaSemanalMigVul(const std::vector<std::string>& vcLenguajes, const std::string& sTipoDeMigracion)
{
	std::map<std::string, int> mapOcurrencias;

	for (const auto& sLenguaje : vcLenguajes)
	{
		//validar el tipo de lenguaje que entro por parámetro y si el tipo de migración es mig o vul.
		if (sLenguaje.compare(".php") == 0 || sLenguaje.compare(".PHP") == 0)
		{
			if (sTipoDeMigracion.compare("mig") == 0)
			{
				// incrementar el numero de ocurrencias
				mapOcurrencias["PHP"] += PHP_MIGRACION_META;
			}
			else if (sTipoDeMigracion.compare("vul") == 0)
			{
				mapOcurrencias["PHP"] += PHP_VULNERABILIDADES_META;
			}
		}
		
		if (sLenguaje.compare(".cpp") == 0 || sLenguaje.compare(".CPP") == 0)
		{
			if (sTipoDeMigracion.compare("mig") == 0)
			{
				// incrementar el numero de ocurrencias
				mapOcurrencias["CPP"] += CPP_MIGRACION_META;
			}
			else if (sTipoDeMigracion.compare("vul") == 0)
			{
				mapOcurrencias["CPP"] += CPP_VULNERABILIDADES_META;
			}
		}

		if (sLenguaje.compare(".C") == 0 || sLenguaje.compare(".c") == 0)
		{
			if (sTipoDeMigracion.compare("mig") == 0)
			{
				// incrementar el numero de ocurrencias
				mapOcurrencias["C"] += C_MIGRACION_META;
			}
			else if (sTipoDeMigracion.compare("vul") == 0)
			{
				mapOcurrencias["C"] += C_VULNERABILIDADES_META;
			}
		}	

		if (sLenguaje.compare(".JAVA") == 0 || sLenguaje.compare(".java") == 0)
		{
			if (sTipoDeMigracion.compare("mig") == 0)
			{
				// incrementar el numero de ocurrencias
				mapOcurrencias["JAVA"] += JAVA_MIGRACION_META;
			}
			else if (sTipoDeMigracion.compare("vul") == 0)
			{
				mapOcurrencias["JAVA"] += JAVA_VULNERABILIDADES_META;
			}
		}

		if (sLenguaje.compare(".JS") == 0 || sLenguaje.compare(".js") == 0)
		{
			if (sTipoDeMigracion.compare("mig") == 0)
			{
				// incrementar el numero de ocurrencias
				mapOcurrencias["JS"] += JAVASCRIPT_MIGRACION_META;
			}
			else if (sTipoDeMigracion.compare("vul") == 0)
			{
				mapOcurrencias["JS"] += JAVASCRIPT_VULNERABILIDADES_META;
			}
		}

		if (sLenguaje.compare(".CS") == 0 || sLenguaje.compare(".cs") == 0)
		{
			if (sTipoDeMigracion.compare("mig") == 0)
			{
				// incrementar el numero de ocurrencias
				mapOcurrencias["CS"] += CSHARP_MIGRACION_META;
			}
			else if (sTipoDeMigracion.compare("vul") == 0)
			{
				mapOcurrencias["CS"] += CSHARP_VULNERABILIDADES_META;
			}
		}

		if (sLenguaje.compare(".PY") == 0 || sLenguaje.compare(".py") == 0)
		{
			if (sTipoDeMigracion.compare("mig") == 0)
			{
				// incrementar el numero de ocurrencias
				mapOcurrencias["PY"] += PYTHON_MIGRACION_META;
			}
			else if (sTipoDeMigracion.compare("vul") == 0)
			{
				mapOcurrencias["PY"] += PYTHON_VULNERABILIDADES_META;
			}
		}

		if (sLenguaje.compare(".TS") == 0 || sLenguaje.compare(".ts") == 0)
		{
			if (sTipoDeMigracion.compare("mig") == 0)
			{
				// incrementar el numero de ocurrencias
				mapOcurrencias["TS"] += TYPESCRIPT_MIGRACION_META;
			}
			else if (sTipoDeMigracion.compare("vul") == 0)
			{
				mapOcurrencias["TS"] += TYPESCRIPT_VULNERABILIDADES_META;
			}
		}
	}

	return mapOcurrencias;
}

static void recorrerMapa(const std::map<std::string, int>& mapOcurrencias)
{
	for (const auto& par : mapOcurrencias)
	{
		std::cout << "Lenguaje de programación: " << par.first
			<< ", Número de ocurrencias: " << par.second << std::endl;
	}
}

//static int obtenerOcurrenciasDelVector(const std::vector<std::string>::const_iterator vcLenguajes, const std::string& sTipoDeMigracion)
//{
//	std::string sNumeroOcurrencias;
//	int iNumeroOcurrencias = 0;
//
//	//validar el tipo de lenguaje que entro por parámetro y si el tipo de migración es mig o vul.
//	if (sLenguaje.compare("php") == 0 || sLenguaje.compare("PHP") == 0)
//	{
//		if (sTipoDeMigracion.compare("mig") == 0)
//		{
//			// convertir a entero el numero de ocurrencias
//			sNumeroOcurrencias = std::to_string(PHP_MIGRACION_META);
//		}
//		else if (sTipoDeMigracion.compare("vul") == 0)
//		{
//			sNumeroOcurrencias = std::to_string(PHP_VULNERABILIDADES_META);
//		}
//	}
//	else if (sLenguaje.compare("cpp") == 0 || sLenguaje.compare("CPP") == 0)
//	{
//		if (sTipoDeMigracion.compare("mig") == 0)
//		{
//			sNumeroOcurrencias = std::to_string(CPP_MIGRACION_META);
//		}
//		else if (sTipoDeMigracion.compare("vul") == 0)
//		{
//			sNumeroOcurrencias = std::to_string(CPP_VULNERABILIDADES_META);
//		}
//	}
//	else if (sLenguaje.compare("C") == 0 || sLenguaje.compare("c") == 0)
//	{
//		if (sTipoDeMigracion.compare("mig") == 0)
//		{
//			sNumeroOcurrencias = std::to_string(C_MIGRACION_META);
//		}
//		else if (sTipoDeMigracion.compare("vul") == 0)
//		{
//			sNumeroOcurrencias = std::to_string(C_VULNERABILIDADES_META);
//		}
//	}
//	else if (sLenguaje.compare("JAVA") == 0 || sLenguaje.compare("java") == 0)
//	{
//		if (sTipoDeMigracion.compare("mig") == 0)
//		{
//			sNumeroOcurrencias = std::to_string(JAVA_MIGRACION_META);
//		}
//		else if (sTipoDeMigracion.compare("vul") == 0)
//		{
//			sNumeroOcurrencias = std::to_string(JAVA_VULNERABILIDADES_META);
//		}
//	}
//	else if (sLenguaje.compare("JS") == 0 || sLenguaje.compare("js") == 0)
//	{
//		if (sTipoDeMigracion.compare("mig") == 0)
//		{
//			sNumeroOcurrencias = std::to_string(JAVASCRIPT_MIGRACION_META);
//		}
//		else if (sTipoDeMigracion.compare("vul") == 0)
//		{
//			sNumeroOcurrencias = std::to_string(JAVASCRIPT_VULNERABILIDADES_META);
//		}
//	}
//	else if (sLenguaje.compare("CS") == 0 || sLenguaje.compare("cs") == 0)
//	{
//		if (sTipoDeMigracion.compare("mig") == 0)
//		{
//			sNumeroOcurrencias = std::to_string(CSHARP_MIGRACION_META);
//		}
//		else if (sTipoDeMigracion.compare("vul") == 0)
//		{
//			sNumeroOcurrencias = std::to_string(CSHARP_VULNERABILIDADES_META);
//		}
//	}
//	else if (sLenguaje.compare("PY") == 0 || sLenguaje.compare("py") == 0)
//	{
//		if (sTipoDeMigracion.compare("mig") == 0)
//		{
//			sNumeroOcurrencias = std::to_string(PYTHON_MIGRACION_META);
//		}
//		else if (sTipoDeMigracion.compare("vul") == 0)
//		{
//			sNumeroOcurrencias = std::to_string(PYTHON_VULNERABILIDADES_META);
//		}
//	}
//	else if (sLenguaje.compare("TS") == 0 || sLenguaje.compare("ts") == 0)
//	{
//		if (sTipoDeMigracion.compare("mig") == 0)
//		{
//			sNumeroOcurrencias = std::to_string(TYPESCRIPT_MIGRACION_META);
//		}
//		else if (sTipoDeMigracion.compare("vul") == 0)
//		{
//			sNumeroOcurrencias = std::to_string(TYPESCRIPT_VULNERABILIDADES_META);
//		}
//	}
//	else
//	{
//		std::cout << "Error: Por favor captura solo la extensión del lenguaje. Ejemplo (PHP, CPP, TS, JS, C, JAVA, Etc...)" << std::endl;
//		return 1;
//	}
//
//	//convertir sNumeroOcurrencias a int
//	iNumeroOcurrencias = std::stoi(sNumeroOcurrencias);
//
//	return iNumeroOcurrencias;
//}

void validateParameters(std::string &sRutaProyecto, std::string &sLenguaje, std::string &sTipoMigracion, std::string &sNumColaboradores) 
{
	bool bParametrosCorrectos = false;

	while (!bParametrosCorrectos)
	{
		std::cout << "Ingrese la ruta del proyecto: ";
		std::cin >> sRutaProyecto;

		std::cout << "Ingrese el lenguaje: ";
		std::cin >> sLenguaje;

		std::cout << "Ingrese el tipo de migración (mig o vul): ";
		std::cin >> sTipoMigracion;

		std::cout << "Ingrese el número de colaboradores: ";
		std::cin >> sNumColaboradores;

		// Validar los parámetros de entrada
		if (!sRutaProyecto.empty() && !sLenguaje.empty() && (sTipoMigracion == "mig" || sTipoMigracion == "vul") && atoi(sNumColaboradores.c_str()) > 0) 
		{
			bParametrosCorrectos = true;
		}
		else 
		{
			std::cout << "Los parámetros ingresados son incorrectos. Por favor, inténtelo nuevamente." << std::endl;
		}
	}
}



void validateParametersAll(std::string& sRutaProyecto, std::string& sTipoMigracion, std::string& sNumColaboradores)
{
	bool bParametrosCorrectos = false;

	std::cout << "-----------------------------------------------------" << std::endl;
	std::cout << " Herramienta de Migración y Vulnerabilidades con IA  " << std::endl;
	std::cout << "    Favor de capturar la información solicitada.     " << std::endl;
	std::cout << "_____________________________________________________" << std::endl;
	std::cout << "" << std::endl;

	while (!bParametrosCorrectos)
	{
		std::cout << "Ingrese la ruta del proyecto: ";
		std::cin >> sRutaProyecto;

		std::cout << "Ingrese el tipo de migración (mig o vul): ";
		std::cin >> sTipoMigracion;

		std::cout << "Ingrese el número de colaboradores: ";
		std::cin >> sNumColaboradores;

		// Validar los parámetros de entrada
		if (!sRutaProyecto.empty() && (sTipoMigracion == "mig" || sTipoMigracion == "vul") && atoi(sNumColaboradores.c_str()) > 0)
		{
			bParametrosCorrectos = true;
		}
		else
		{
			std::cout << "Los parámetros ingresados son incorrectos. Por favor, inténtelo nuevamente." << std::endl;
		}
	}
}